#include "pll.h"
#include <queue>
#include <unordered_set>
#include <algorithm>
#include <vector>
#include <map> 
#include <unordered_map>
// 构造函数，接收图结构
PLL::PLL(Graph& graph) : g(graph) {}

// 从特定路径 Pk 出发的剪枝 BFS，用于构建2-hop索引
void PLL::bfsPruned(int start, bool is_reversed) {
    std::queue<int> q;
    std::unordered_map<int, int> distances;  // 距离标记
    q.push(start);
    distances[start] = 0;

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        // 选择邻接表方向
        const auto& neighbors = is_reversed ? g.vertices[current].LIN : g.vertices[current].LOUT;
        for (int neighbor : neighbors) {
            // 剪枝条件：若标签交集已有路径可达，则停止扩展
            const auto& start_labels = is_reversed ? g.vertices[start].LIN : g.vertices[start].LOUT;
            const auto& neighbor_labels = is_reversed ? g.vertices[neighbor].LOUT : g.vertices[neighbor].LIN;
            bool should_prune = false;

            for (int label : start_labels) {
                if (std::find(neighbor_labels.begin(), neighbor_labels.end(), label) != neighbor_labels.end()) {
                    should_prune = true;
                    break;
                }
            }
            if (should_prune) continue;  // 通过交集判断剪枝

            // 更新标签集合
            if (is_reversed) {
                g.vertices[neighbor].LIN.push_back(start); // 更新反向标签
            } else {
                g.vertices[neighbor].LOUT.push_back(start); // 更新前向标签
            }

            // 扩展到下一层
            if (distances.find(neighbor) == distances.end()) {
                distances[neighbor] = distances[current] + 1;
                q.push(neighbor);
            }
        }
    }
}

// 构建2-hop标签的PLL主函数
void PLL::buildPLLLabels() {
    for (int node = 0; node < g.vertices.size(); ++node) {
        bfsPruned(node, false);  // 正向BFS，构建LOUT
        bfsPruned(node, true);   // 反向BFS，构建LIN
    }
}

// 可达性查询，检查是否存在2-hop路径
bool PLL::reachabilityQuery(int u, int v) {
    if (u >= g.vertices.size() || v >= g.vertices.size()) return false;

    // 比较 u 的前向标签和 v 的后向标签
    const auto& LOUT_u = g.vertices[u].LOUT;
    const auto& LIN_v = g.vertices[v].LIN;

    std::unordered_set<int> loutSet(LOUT_u.begin(), LOUT_u.end());
    for (int node : LIN_v) {
        if (loutSet.count(node)) return true;  // 存在交集，表示可达
    }
    return false;  // 无交集，不可达
}

// 贪婪算法求解2-Hop覆盖
std::vector<int> PLL::greedy2HopCover() {
    std::vector<int> selectedNodes;
    std::unordered_set<int> coveredNodes;

    // 使用 multimap 来模拟最大堆，选择覆盖节点最多的节点
    std::multimap<int, int, std::greater<int>> cover_count_to_node;

    // 初始化覆盖计数
    for (int node = 0; node < g.vertices.size(); ++node) {
        int uncoveredCount = 0;
        for (int neighbor : g.vertices[node].LOUT) {
            if (coveredNodes.find(neighbor) == coveredNodes.end()) {
                uncoveredCount++;
            }
        }
        if (uncoveredCount > 0) {
            cover_count_to_node.insert(std::make_pair(uncoveredCount, node));
        }
    }

    // 迭代选择覆盖最多的节点
    while (coveredNodes.size() < g.vertices.size()) {
        if (cover_count_to_node.empty()) break;

        // 选择堆顶的节点
        auto it = cover_count_to_node.begin();
        int bestNode = it->second;
        cover_count_to_node.erase(it);

        selectedNodes.push_back(bestNode);
        for (int neighbor : g.vertices[bestNode].LOUT) {
            coveredNodes.insert(neighbor);
        }

        // 更新堆中剩余节点的覆盖计数
        std::multimap<int, int, std::greater<int>> new_cover_count_to_node;
        for (auto entry = cover_count_to_node.begin(); entry != cover_count_to_node.end(); ++entry) {
            int node = entry->second;
            int updated_count = 0;
            for (int neighbor : g.vertices[node].LOUT) {
                if (coveredNodes.find(neighbor) == coveredNodes.end()) {
                    updated_count++;
                }
            }
            if (updated_count > 0) {
                new_cover_count_to_node.insert(std::make_pair(updated_count, node));
            }
        }
        cover_count_to_node = std::move(new_cover_count_to_node);
    }

    return selectedNodes;
}
