#include "gtest/gtest.h"
#include "pll.h"
#include "graph.h"
#include "BidirectionalBFS.h"
#include "OutputHandler.h"
#include "RandomUtils.h"
#include "InputHandler.h"
TEST(PLLTest, ReachabilityTest) {
    Graph g(true);

    // 使用项目根目录宏构建绝对路径
    
    InputHandler inputHandler(PROJECT_ROOT_DIR"/Edges/generate/gene_edges_20241029_135003");
    inputHandler.readGraph(g);
    OutputHandler::printGraphInfo(g);
    OutputHandler outputHandler2(PROJECT_ROOT_DIR"/result/135003_2hoplabels_origin");
    OutputHandler outputHandler(PROJECT_ROOT_DIR"/result/135003_2hoplabels_pruned");
    // 生成不重复的随机查询对
    int num_queries = 100;
    int max_value = g.vertices.size();
    unsigned int seed = 42; // 可选的随机种子

    std::vector<std::pair<int, int>> query_pairs = RandomUtils::generateUniqueQueryPairs(num_queries, max_value, seed);

    outputHandler2.writeInOutSets(g);
    PLL pll(g);
    pll.buildPLLLabels();
    outputHandler.writeInOutSets(g);
    
    for (const auto& query_pair : query_pairs) {
        int source = query_pair.first;
        int target = query_pair.second;
        bool result = pll.reachabilityQuery(source, target);
        std::cout << "Query from " << source << " to " << target << ": " << (result ? "Reachable" : "Not Reachable") << std::endl;
    }


}
